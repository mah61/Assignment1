﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// finding the unique elements in an Array
namespace Assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] myArr = {3,7,14,3,25,7,25,6,12};
            GetUinque(myArr);
        }

        //Creating a method to find unique elements

        static void GetUinque(int[] myArr)
        {            
            Array.Sort(myArr);
            int tempElement = 0; //defining a temp element in order to check repeated value inside the loop
            int[] uniqueArr = new int[myArr.Length];  //defining a new array for the unique elements
            int k = 0;    // index for uniqueArr
            int i = 0;

            for (i = 0; i < myArr.Length - 1; i++)
            {

                if (myArr[i] == myArr[i + 1])
                {
                    tempElement = myArr[i];
                }
                else if (myArr[i] != myArr[i + 1] && myArr[i] != tempElement)
                {

                    uniqueArr[k++] = myArr[i];
                }
            }

            //condition for the last element of the array
            if (myArr[i] != myArr[myArr.Length - 2])  
             {
                uniqueArr[uniqueArr.Length - 1] = myArr[myArr.Length - 1];
             }
                // print the unique elements 
                for(int x = 0; x < uniqueArr.Length; x++)
                {
                   if (uniqueArr[x] != 0)
                {
                     Console.WriteLine("element {0} is unique", uniqueArr[x]);
                }
                
                }
            }
        }
    }

